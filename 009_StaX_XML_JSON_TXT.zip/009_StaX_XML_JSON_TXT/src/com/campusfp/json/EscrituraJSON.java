package com.campusfp.json;

import java.io.FileWriter;
import java.io.IOException;
import com.campusfp.xml.Alumno;
import org.json.simple.JSONObject;


public class EscrituraJSON {

@SuppressWarnings("unchecked")
public static void main(String[] args) throws IOException {
	 
	//Creamos un alumno de ejemplo
	 Alumno alumno = new Alumno("Guille", "Gri�on", 500);
	 
	//Creamos el objeto para meter al JSON
	JSONObject obj = new JSONObject();
	obj.put("Nombre", alumno.getNombre());
	obj.put("Ciudad", alumno.getCiudad());
	obj.put("Salario", alumno.getSalario());



	//Creacion del JSON en la raiz del proyecto + impresion por consola
	try (FileWriter file = new FileWriter(".\\archivoJSON.txt")) {
		file.write(obj.toJSONString());
		System.out.println("Se ha creado correctamente");
		System.out.println("\nJSON Object: " + obj);
	}
}

}

