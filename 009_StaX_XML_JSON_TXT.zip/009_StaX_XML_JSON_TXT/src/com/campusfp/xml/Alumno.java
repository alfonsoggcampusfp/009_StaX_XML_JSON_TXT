package com.campusfp.xml;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class Alumno {

	String nombre;
	String ciudad;
	int salario;
	
	public Alumno(String nombre, String ciudad, int salario) {
		this.nombre = nombre;
		this.ciudad = ciudad;
		this.salario = salario;
	}
	
	public Alumno() {

	}
	
	public String getNombre() {
		return nombre;
	}
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	public String getCiudad() {
		return ciudad;
	}
	public void setCiudad(String ciudad) {
		this.ciudad = ciudad;
	}
	public int getSalario() {
		return salario;
	}
	public void setSalario(int salario) {
		this.salario = salario;
	}
	
	@Override
	public String toString() {
		return "Alumno [nombre=" + nombre + ", ciudad=" + ciudad + ", salario=" + salario + "]";
	}
	
}
