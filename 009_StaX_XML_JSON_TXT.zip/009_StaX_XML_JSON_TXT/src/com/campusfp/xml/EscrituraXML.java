package com.campusfp.xml;



import java.io.File;
 
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
 
public class EscrituraXML 
{
    public static void main(String[] args) 
    {
    	
        //Java object. We will convert it to XML.
        Alumno alumno = new Alumno("Guille", "Gri�on", 500);
         
        //Method which uses JAXB to convert object to XML
        jaxbObjectToXML(alumno);
    }
 
    private static void jaxbObjectToXML(Alumno alumno) 
    {
        try
        {
            //Create JAXB Context
            JAXBContext jaxbContext = JAXBContext.newInstance(Alumno.class);
             
            //Create Marshaller
            Marshaller jaxbMarshaller = jaxbContext.createMarshaller();
 
            //Required formatting??
            jaxbMarshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, Boolean.TRUE);
 
          //Store XML to File
            File file = new File(".\\config.xml");
             
            //Writes XML file to file-system
            jaxbMarshaller.marshal(alumno, file);
 
        } catch (JAXBException e) {
            e.printStackTrace();
        }
    }
}
	

