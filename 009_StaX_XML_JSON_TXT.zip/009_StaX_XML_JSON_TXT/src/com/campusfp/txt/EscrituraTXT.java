package com.campusfp.txt;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;


import com.campusfp.xml.Alumno;

public class EscrituraTXT {

	
	
	public static void main(String[] args) throws IOException {
		//variables
		String ruta = "C://009_StaX_XML_JSON_TXT/archivo.txt";
        File archivo = new File(ruta);
        BufferedWriter bw;
        
        Alumno alumno = new Alumno("Guille", "Grinon", 500);
        
        if(archivo.exists()) {
        	//A�adimos los datos del alumno al archivo
            bw = new BufferedWriter(new FileWriter(archivo));
            bw.write("Alumno: " + alumno.getNombre() + ", Ciudad : " + alumno.getCiudad() + ", Salario : " + alumno.getSalario());

        } else {
        	//A�adimos los datos del alumno al archivo
            bw = new BufferedWriter(new FileWriter(archivo));
            bw.write("Alumno: " + alumno.getNombre() + ", Ciudad : " + alumno.getCiudad() + ", Salario : " + alumno.getSalario());
        }
        bw.close();
    }
}
