package com.campusfp.txt;

import java.io.File;
import java.io.IOException;
import java.util.Scanner;

public class LecturaTXT {
	
	
	public static void main(String[] args) throws IOException{
		
		String ruta = "C://009_StaX_XML_JSON_TXT/archivo.txt";
		
		File file = new File(ruta);
		
		Scanner sc = new Scanner(file);
		
		System.out.println(sc.nextLine());
	}
	
	
}
